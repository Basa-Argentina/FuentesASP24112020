CREATE VIEW dbo.[Email CLientes]
AS
SELECT        codigo_cliente AS [Codigo Cliente], nombre_cliente AS Cliente, emails AS Correo
FROM            dbo.email_clientes
go

