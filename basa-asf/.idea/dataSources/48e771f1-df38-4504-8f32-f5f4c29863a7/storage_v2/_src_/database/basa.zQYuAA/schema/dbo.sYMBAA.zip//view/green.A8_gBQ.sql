CREATE VIEW dbo.Green
AS
SELECT        dbo.elementos.clienteEmp_id AS cliente_empleado_id, dbo.referencia.elemento_id, dbo.elementos.codigo, dbo.referencia.numero1, dbo.referencia.numero2, dbo.referencia.fechaHora, dbo.referencia.pathLegajo, 
                         dbo.elementos.contenedor_id AS nro_caja, dbo.elementos.tipoElemento_id, dbo.referencia.cImagenes, dbo.lotereferencia.codigo AS LoteCodigo
FROM            dbo.referencia INNER JOIN
                         dbo.elementos ON dbo.referencia.elemento_id = dbo.elementos.id INNER JOIN
                         dbo.lotereferencia ON dbo.referencia.lote_referencia_id = dbo.lotereferencia.id
WHERE        (dbo.elementos.tipoElemento_id = 2) AND (dbo.elementos.clienteEmp_id = 20026) AND (dbo.referencia.fechaHora >= CONVERT(DATETIME, '2016-04-01 00:00:00', 102))
go

