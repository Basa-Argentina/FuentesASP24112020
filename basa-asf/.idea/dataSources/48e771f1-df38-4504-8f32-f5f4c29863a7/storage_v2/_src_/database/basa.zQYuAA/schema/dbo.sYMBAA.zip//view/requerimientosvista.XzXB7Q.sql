CREATE VIEW dbo.[REQUERIMIENTOS.VISTA]
AS
SELECT        dbo.requerimiento.numero, dbo.x_requerimiento_referencia.requerimiento_id, dbo.x_requerimiento_referencia.elemento_id
FROM            dbo.requerimiento INNER JOIN
                         dbo.x_requerimiento_referencia ON dbo.requerimiento.id = dbo.x_requerimiento_referencia.requerimiento_id
go

