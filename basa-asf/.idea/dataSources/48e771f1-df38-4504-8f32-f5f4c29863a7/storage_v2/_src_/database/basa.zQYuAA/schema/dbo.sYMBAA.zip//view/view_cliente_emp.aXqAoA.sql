CREATE VIEW dbo.View_Cliente_Emp
AS
SELECT        dbo.personas_juridicas.razonSocial, dbo.clientesEmp.id, dbo.clientesEmp.codigo
FROM            dbo.clientesEmp INNER JOIN
                         dbo.personas_juridicas ON dbo.clientesEmp.razonSocial_id = dbo.personas_juridicas.id
go

