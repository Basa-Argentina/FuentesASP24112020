/****** Script for SelectTopNRows command from SSMS  ******/
CREATE VIEW dbo.View_clienteEmpleados
AS
SELECT        dbo.clienteEmpleados.clienteEmp_id AS clienteEmpleados_clienteEmp_id, dbo.clienteEmpleados.id AS clienteEmpleados_ID, dbo.clienteEmpleados.codigo AS clienteEmpleados_codigo, 
                         dbo.personas_fisicas.nombre AS personas_fisicas_nombre, dbo.personas_fisicas.apellido AS personas_fisicas_apellido, dbo.users.username, dbo.personas.mail, dbo.clasificacionDocumental.nombre AS sucursal
FROM            dbo.clasificacionDocumental INNER JOIN
                         dbo.x_clasificacionDocumental_clienteEmpleados ON dbo.clasificacionDocumental.id = dbo.x_clasificacionDocumental_clienteEmpleados.clasificacionDocumental_id RIGHT OUTER JOIN
                         dbo.clienteEmpleados INNER JOIN
                         dbo.users ON dbo.clienteEmpleados.id = dbo.users.id INNER JOIN
                         dbo.personas ON dbo.users.persona_id = dbo.personas.id INNER JOIN
                         dbo.personas_fisicas ON dbo.personas.id = dbo.personas_fisicas.id ON dbo.x_clasificacionDocumental_clienteEmpleados.clienteEmpleados_id = dbo.clienteEmpleados.id AND 
                         dbo.x_clasificacionDocumental_clienteEmpleados.clienteEmpleados_id = dbo.clienteEmpleados.id
go

