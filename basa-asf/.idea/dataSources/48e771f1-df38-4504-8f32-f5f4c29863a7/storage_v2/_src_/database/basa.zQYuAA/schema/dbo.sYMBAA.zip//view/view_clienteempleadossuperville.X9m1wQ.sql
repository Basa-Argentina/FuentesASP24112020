/****** Script for SelectTopNRows command from SSMS  ******/
CREATE VIEW dbo.View_ClienteEmpleadosSuperville
AS
SELECT        dbo.View_clienteEmpleados.clienteEmpleados_clienteEmp_id, dbo.View_clienteEmpleados.clienteEmpleados_ID, dbo.View_clienteEmpleados.clienteEmpleados_codigo, dbo.View_clienteEmpleados.personas_fisicas_nombre, 
                         dbo.View_clienteEmpleados.personas_fisicas_apellido, clasificacionDocumental_1.nombre AS Provincia, CONVERT(char(5), dbo.clasificacionDocumental.codigo) + ' ' + dbo.clasificacionDocumental.nombre AS Sucursal, 
                         dbo.clasificacionDocumental.id AS id_clasificacionDocumental, dbo.clasificacionDocumental.kilometrosEnvio
FROM            dbo.clasificacionDocumental INNER JOIN
                         dbo.x_clasificacionDocumental_clienteEmpleados ON dbo.clasificacionDocumental.id = dbo.x_clasificacionDocumental_clienteEmpleados.clasificacionDocumental_id INNER JOIN
                         dbo.clasificacionDocumental AS clasificacionDocumental_1 ON dbo.clasificacionDocumental.padre_id = clasificacionDocumental_1.id AND 
                         dbo.clasificacionDocumental.padre_id = clasificacionDocumental_1.id RIGHT OUTER JOIN
                         dbo.View_clienteEmpleados INNER JOIN
                         dbo.View_Cliente_Emp ON dbo.View_clienteEmpleados.clienteEmpleados_clienteEmp_id = dbo.View_Cliente_Emp.id ON 
                         dbo.x_clasificacionDocumental_clienteEmpleados.clienteEmpleados_id = dbo.View_clienteEmpleados.clienteEmpleados_ID
WHERE        (dbo.View_clienteEmpleados.clienteEmpleados_clienteEmp_id IN (20042))
go

