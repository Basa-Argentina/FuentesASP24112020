/****** Script for SelectTopNRows command from SSMS  ******/
CREATE VIEW dbo.View_Control_Pendientes
AS
SELECT        dbo.View_Cliente_Emp.razonSocial, dbo.tipos_requerimiento.descripcion, dbo.requerimiento.numero AS Nª_Requerimiento, CONVERT(char, dbo.requerimiento.fechaAlta, 103) AS FechaAlta, CONVERT(char, 
                         dbo.requerimiento.fechaEntrega, 103) AS fechaEntrega, dbo.requerimiento.estado, dbo.remitos.cantidadElementos, CONVERT(numeric, dbo.remitos.numeroSinPrefijo) AS Nª_Remito, dbo.requerimiento.hojaRuta_id, 
                         dbo.hojaRuta.numero, dbo.hojaRuta.serie_id
FROM            dbo.hojaRuta RIGHT OUTER JOIN
                         dbo.requerimiento INNER JOIN
                         dbo.View_Cliente_Emp ON dbo.requerimiento.clienteEmp_id = dbo.View_Cliente_Emp.id INNER JOIN
                         dbo.tipos_requerimiento ON dbo.requerimiento.tipoRequerimiento_id = dbo.tipos_requerimiento.id AND dbo.requerimiento.tipoRequerimiento_id = dbo.tipos_requerimiento.id ON 
                         dbo.hojaRuta.id = dbo.requerimiento.hojaRuta_id LEFT OUTER JOIN
                         dbo.remitos ON dbo.requerimiento.remito_id = dbo.remitos.id LEFT OUTER JOIN
                         dbo.operacion ON dbo.requerimiento.id = dbo.operacion.requerimiento_id
WHERE        (dbo.requerimiento.estado = 'Pendiente') AND (NOT (CONVERT(numeric, dbo.remitos.numeroSinPrefijo) IS NULL))
go

