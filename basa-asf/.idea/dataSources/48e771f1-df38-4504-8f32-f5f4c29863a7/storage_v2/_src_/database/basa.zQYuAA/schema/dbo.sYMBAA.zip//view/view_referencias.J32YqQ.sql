/****** Script para el comando SelectTopNRows de SSMS  ******/
CREATE VIEW dbo.VIEW_REFERENCIAS
AS
SELECT        dbo.elementos.codigo AS ETIQUETA, elementos_1.codigo AS CAJA, dbo.elementos.clienteEmp_id AS ID_CLIENTE, dbo.personas_juridicas.razonSocial AS RAZON_SOCIAL, 
                         dbo.clasificacionDocumental.nombre AS TIPO_DOCUMENTO, dbo.referencia.numero1 AS NRO_DESDE, dbo.referencia.numero2 AS NRO_HASTA, dbo.referencia.texto1 AS LETRA_DESDE, dbo.referencia.texto2 AS LETRA_HASTA, 
                         LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(dbo.referencia.descripcion, CHAR(9), ''), CHAR(13), ''), CHAR(10), ''))) AS DESCRIPCION, CONVERT(nvarchar, dbo.referencia.fecha1, 103) AS FECHA_DESDE, CONVERT(NVARCHAR, 
                         dbo.referencia.fecha2, 103) AS FECHA_HASTA, dbo.referencia.pathLegajo, dbo.lotereferencia.codigo AS NumeroLote, dbo.referencia.clasificacion_documental_id, dbo.clientesEmp.codigo, dbo.referencia.fechaHora, 
                         dbo.users.username, dbo.referencia.cImagenes, elementos_1.estado AS Estado_caja
FROM            dbo.users INNER JOIN
                         dbo.referencia INNER JOIN
                         dbo.elementos ON dbo.referencia.elemento_id = dbo.elementos.id INNER JOIN
                         dbo.clientesEmp ON dbo.elementos.clienteEmp_id = dbo.clientesEmp.id INNER JOIN
                         dbo.personas_juridicas ON dbo.clientesEmp.razonSocial_id = dbo.personas_juridicas.id INNER JOIN
                         dbo.clasificacionDocumental ON dbo.referencia.clasificacion_documental_id = dbo.clasificacionDocumental.id AND dbo.clientesEmp.id = dbo.clasificacionDocumental.cliente_emp_id AND 
                         dbo.clientesEmp.id = dbo.clasificacionDocumental.cliente_emp_id INNER JOIN
                         dbo.lotereferencia ON dbo.referencia.lote_referencia_id = dbo.lotereferencia.id AND dbo.clientesEmp.id = dbo.lotereferencia.cliente_emp_id INNER JOIN
                         dbo.referencias_historico ON dbo.referencia.id = dbo.referencias_historico.idReferencia ON dbo.users.id = dbo.referencias_historico.usuario_id LEFT OUTER JOIN
                         dbo.elementos AS elementos_1 ON dbo.elementos.contenedor_id = elementos_1.id
go

