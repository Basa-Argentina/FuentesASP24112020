/****** Script for SelectTopNRows command from SSMS  ******/
CREATE VIEW dbo.View_Remito_movimiento_elementos
AS
SELECT        TOP (100) PERCENT dbo.remitos.numeroSinPrefijo AS NumeroDeRemito, dbo.movimientos.codigoCarga, dbo.movimientos.tipoMovimiento, dbo.remitos.fechaEmision, dbo.remitos.fechaEntrega, 
                         dbo.movimientos.claseMovimiento, dbo.movimientos.estadoElemento, dbo.movimientos.elemento_id, dbo.elementos.codigo, dbo.elementos.estado
FROM            dbo.remitos INNER JOIN
                         dbo.movimientos ON dbo.remitos.id = dbo.movimientos.remito_id INNER JOIN
                         dbo.elementos ON dbo.movimientos.elemento_id = dbo.elementos.id
WHERE        (dbo.remitos.numeroSinPrefijo LIKE '%77519%')
ORDER BY dbo.movimientos.codigoCarga
go

