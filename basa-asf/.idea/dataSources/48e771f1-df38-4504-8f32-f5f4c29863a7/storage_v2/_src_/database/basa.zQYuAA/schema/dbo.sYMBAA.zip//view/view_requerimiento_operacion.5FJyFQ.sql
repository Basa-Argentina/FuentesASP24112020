/****** Script for SelectTopNRows command from SSMS  ******/
CREATE VIEW dbo.View_Requerimiento_Operacion
AS
SELECT        TOP (1000) dbo.requerimiento.numero, dbo.requerimiento.id AS requerimiento_id, dbo.requerimiento.estado AS requerimiento_estado, dbo.requerimiento.fechaAlta, dbo.requerimiento.fechaCierre, 
                         dbo.requerimiento.fechaEntrega, dbo.requerimiento.horaAlta, dbo.requerimiento.horaEntrega, dbo.requerimiento.numero AS requerimiento_numero, dbo.requerimiento.prefijo, dbo.requerimiento.clienteAsp_id, 
                         dbo.requerimiento.clienteEmp_id, dbo.requerimiento.direccionDefecto_id, dbo.requerimiento.empleadoAutorizante_id, dbo.requerimiento.empleadoSolicitante_id, dbo.requerimiento.serie_id, dbo.requerimiento.sucursal_id, 
                         dbo.requerimiento.tipoRequerimiento_id, dbo.requerimiento.usuario_id, dbo.requerimiento.depositoDefecto_id, dbo.requerimiento.horaCierre, dbo.requerimiento.listaPrecios_id, dbo.requerimiento.observaciones, 
                         dbo.requerimiento.cantidad, dbo.requerimiento.remito_id, dbo.requerimiento.hojaRuta_id, dbo.operacion.tipoOperacion_id, dbo.operacion.codigo, dbo.elementos.codigo AS elementos_codigo, 
                         elementos_1.codigo AS elementos_1_codigo, dbo.x_operacion_elemento.id, dbo.x_operacion_elemento.estado, dbo.x_operacion_elemento.elemento_id, dbo.x_operacion_elemento.operacion_id, 
                         dbo.x_operacion_elemento.traspasado, dbo.x_operacion_elemento.facturado, dbo.x_operacion_elemento.provieneLectura, dbo.x_operacion_elemento.rearchivoDe_id, dbo.x_operacion_elemento.pathArchivoDigital
FROM            dbo.x_operacion_elemento INNER JOIN
                         dbo.operacion ON dbo.x_operacion_elemento.operacion_id = dbo.operacion.id INNER JOIN
                         dbo.elementos ON dbo.x_operacion_elemento.elemento_id = dbo.elementos.id AND dbo.x_operacion_elemento.elemento_id = dbo.elementos.id INNER JOIN
                         dbo.elementos AS elementos_1 ON dbo.elementos.contenedor_id = elementos_1.id RIGHT OUTER JOIN
                         dbo.requerimiento ON dbo.operacion.requerimiento_id = dbo.requerimiento.id
ORDER BY dbo.requerimiento.numero
go

