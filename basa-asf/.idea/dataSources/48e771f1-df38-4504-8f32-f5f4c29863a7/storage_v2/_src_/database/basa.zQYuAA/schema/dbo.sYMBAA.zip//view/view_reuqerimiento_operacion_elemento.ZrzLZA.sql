/****** Script for SelectTopNRows command from SSMS  ******/
CREATE VIEW dbo.View_Reuqerimiento_operacion_elemento
AS
SELECT        TOP (100) PERCENT dbo.requerimiento.numero AS Numero_Requerimiento, dbo.requerimiento.id AS id_requerimiento, dbo.operacion.id AS id_operacion, dbo.operacion.codigo AS codigo_operacion, 
                         dbo.tipos_operacion.codigo AS Tipo_Operacion_Codigo, dbo.tipos_operacion.descripcion, dbo.requerimiento.prefijo, dbo.operacion.id, dbo.operacion.cantidadOmitidos, dbo.operacion.cantidadPendientes, 
                         dbo.operacion.cantidadProcesados, dbo.operacion.cantidadProcesadosParaTraspaso, dbo.operacion.finalizarError, dbo.operacion.finalizarOK, dbo.operacion.traspasar, dbo.operacion.cantidadImpresiones, 
                         dbo.x_operacion_elemento.elemento_id, dbo.elementos.codigo
FROM            dbo.elementos INNER JOIN
                         dbo.x_operacion_elemento ON dbo.elementos.id = dbo.x_operacion_elemento.elemento_id AND dbo.elementos.id = dbo.x_operacion_elemento.elemento_id RIGHT OUTER JOIN
                         dbo.requerimiento INNER JOIN
                         dbo.operacion ON dbo.requerimiento.id = dbo.operacion.requerimiento_id INNER JOIN
                         dbo.tipos_operacion ON dbo.operacion.tipoOperacion_id = dbo.tipos_operacion.id AND dbo.operacion.tipoOperacion_id = dbo.tipos_operacion.id ON dbo.x_operacion_elemento.operacion_id = dbo.operacion.id
ORDER BY id_requerimiento DESC
go

