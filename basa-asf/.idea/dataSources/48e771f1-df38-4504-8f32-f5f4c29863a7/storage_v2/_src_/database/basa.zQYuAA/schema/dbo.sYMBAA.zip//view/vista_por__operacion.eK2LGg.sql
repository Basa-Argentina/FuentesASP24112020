/****** Script para el comando SelectTopNRows de SSMS  ******/
CREATE VIEW dbo.[vista_por _operacion]
AS
SELECT        TOP (100) PERCENT dbo.operacion.id, dbo.elementos.codigo AS legajo, elementos_1.codigo AS Caja, dbo.elementos.estado
FROM            dbo.x_operacion_elemento INNER JOIN
                         dbo.operacion ON dbo.x_operacion_elemento.operacion_id = dbo.operacion.id INNER JOIN
                         dbo.elementos ON dbo.x_operacion_elemento.elemento_id = dbo.elementos.contenedor_id INNER JOIN
                         dbo.elementos AS elementos_1 ON dbo.elementos.contenedor_id = elementos_1.id AND dbo.x_operacion_elemento.elemento_id = elementos_1.id
ORDER BY dbo.x_operacion_elemento.operacion_id
go

