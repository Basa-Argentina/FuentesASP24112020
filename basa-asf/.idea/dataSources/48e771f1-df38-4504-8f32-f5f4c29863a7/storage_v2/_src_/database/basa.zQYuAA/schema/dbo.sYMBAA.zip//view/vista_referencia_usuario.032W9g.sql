/****** Script para el comando SelectTopNRows de SSMS  ******/
CREATE VIEW dbo.vista_referencia_usuario
AS
SELECT        dbo.referencias_historico.id, dbo.referencias_historico.accion, dbo.referencias_historico.codigoCliente, CONVERT(char, dbo.referencias_historico.fechaHora, 103) 
                         AS fecha, DATEPART(HH, dbo.referencias_historico.fechaHora) AS hora, DATEPART(mi, dbo.referencias_historico.fechaHora) AS minuto, 
                         dbo.referencias_historico.fechaHora, dbo.referencias_historico.idLoteReferencia, dbo.referencias_historico.idReferencia, dbo.referencias_historico.nombreCliente, 
                         dbo.referencias_historico.clienteAsp_id, dbo.referencias_historico.usuario_id, dbo.referencias_historico.codigoContenedor, 
                         dbo.referencias_historico.codigoElemento, LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(dbo.referencia.descripcion, CHAR(9), ''), CHAR(13), ''), CHAR(10), ''))) 
                         AS descripcion, CONVERT(char, dbo.referencia.fecha1, 103) AS fecha1, CONVERT(char, dbo.referencia.fecha2, 103) AS fecha2, dbo.users.persona_id, 
                         dbo.personas_fisicas.apellido, dbo.personas_fisicas.nombre, dbo.referencia.fecha1 AS Expr1, dbo.referencia.fecha2 AS Expr2, dbo.referencia.numero1, 
                         dbo.referencia.numero2, dbo.referencia.texto1, dbo.referencia.texto2, dbo.referencia.pathLegajo, dbo.referencia.fechaHora AS Expr3, 
                         dbo.referencia.id AS ID_REFERENCIA
FROM            dbo.referencias_historico INNER JOIN
                         dbo.referencia ON dbo.referencias_historico.idReferencia = dbo.referencia.id INNER JOIN
                         dbo.users ON dbo.referencias_historico.usuario_id = dbo.users.id INNER JOIN
                         dbo.personas ON dbo.users.persona_id = dbo.personas.id INNER JOIN
                         dbo.personas_fisicas ON dbo.personas.id = dbo.personas_fisicas.id
go

